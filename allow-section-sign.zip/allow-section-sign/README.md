# Allow Section Sign

Fabric-мод для Minecraft 26.3, который разрешает символ `§` в чате.

Мод убирает `§` из ванильной проверки допустимых символов
(`StringUtil.isAllowedChatCharacter`) одним Mixin-ом.

## Важно

- Для мультиплеера мод должен стоять **и на клиенте, и на сервере**:
  ванильный сервер сам проверяет символы и кикает за «Illegal characters in chat».
- В одиночной игре достаточно поставить мод на клиент.
- Fabric API не нужен.
- На русской раскладке `§` можно набрать через `Alt+0167` (Windows, цифровой блок)
  или вставить из буфера обмена.

## Требования

- Minecraft 26.3
- Fabric Loader 0.19.3+
- Java 25

## Сборка

```
gradle wrapper --gradle-version 9.8.1   # один раз, чтобы создать gradlew
./gradlew build
```

Готовый jar: `build/libs/allow-section-sign-<версия>.jar`
(файл `-sources.jar` ставить не нужно).

## GitHub Actions

`.github/workflows/build.yml` собирает мод при каждом пуше и pull request-е
и выкладывает jar как артефакт. При пуше тега вида `v1.0.0` дополнительно
создаётся GitHub Release с jar-ом.

## Если сборка падает

Если Mixin пишет, что константа `167` не найдена, значит, в 26.3 код
`StringUtil.isAllowedChatCharacter` отличается от ожидаемого. Откройте этот метод
в IDE (`gradle genSources`) и поменяйте инжект в `StringUtilMixin`.

## Лицензия

MIT
