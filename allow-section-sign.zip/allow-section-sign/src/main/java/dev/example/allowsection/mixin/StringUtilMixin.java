package dev.example.allowsection.mixin;

import net.minecraft.util.StringUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(StringUtil.class)
public class StringUtilMixin {

    /**
     * В ваниле проверка выглядит так: c != 167 && c >= ' ' && c != 127.
     * Подменяем 167 (символ §) на -1, и условие "c != -1" всегда истинно,
     * поэтому § перестаёт отсекаться.
     */
    @ModifyConstant(method = "isAllowedChatCharacter", constant = @Constant(intValue = 167))
    private static int allowsection$allowSectionSign(int original) {
        return -1;
    }
}
